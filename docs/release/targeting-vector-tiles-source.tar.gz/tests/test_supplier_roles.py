import sys
from pathlib import Path
from unittest.mock import patch
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import trial_search as search

class RoleTests(unittest.TestCase):
    def test_known_chairs_do_not_use_ai_or_clinics(self):
        with patch.dict("os.environ", {"ANTHROPIC_API_KEY":"test"}), patch("urllib.request.urlopen", side_effect=AssertionError("AI must not replace known supplier rules")):
            intent=search.extend_intent("20 كرسي عيادة", search.interpret("20 كرسي عيادة"))
        self.assertIsNone(search.evidence({"name":"عيادة الأسنان", "evidence_category":"Dental clinic"}, intent))
        self.assertTrue(search.evidence({"name":"الأثاث الطبي", "evidence_category":"Office furniture store"}, intent))
    def test_ai_product_word_alone_is_not_supplier_evidence(self):
        intent={"key":"extended","product":["عياده"],"seller":["medical equipment supplier"],"exclude":[]}
        self.assertIsNone(search.evidence({"name":"عيادة", "evidence_category":"clinic"}, intent))
    def test_bulk_coffee_targets_users_not_competing_sellers(self):
        intent=search.buyer_intent("قهوة بالجملة")
        self.assertTrue(search.evidence({"name":"مقهى", "evidence_category":"coffee shop"},intent))
        self.assertIsNone(search.evidence({"name":"محمصة", "evidence_category":"coffee supplier"},intent))
    def test_rejects_coordinate_reference_as_business_name(self):
        self.assertIsNone(search.evidence({"name":"EPSG:4326", "evidence_category":"Office furniture store"},search.interpret("كراسي")))

if __name__ == "__main__": unittest.main()
