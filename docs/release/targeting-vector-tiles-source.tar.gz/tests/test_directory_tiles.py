import math
import unittest
import mapbox_vector_tile
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from directory_tiles import DirectoryTiles, filter_rows, valid_filters
from trial_search import Directory

class DirectoryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=str(Path(__file__).resolve().parents[1]/'data/targets.parquet')
        cls.tiles=DirectoryTiles(path);cls.directory=Directory(path)
        cls.directory.branch_counts=cls.tiles.branch_counts
    def test_pagination_has_no_ten_cap_and_no_overlap(self):
        first=self.directory.search('بورسلان','Riyadh',limit=30)
        self.assertGreater(first['total'],30);self.assertEqual(len(first['rows']),30)
        next_page=self.directory.search('بورسلان','Riyadh',limit=30,offset=first['next_offset'])
        self.assertFalse(set(r['poi_key'] for r in first['rows'])&set(r['poi_key'] for r in next_page['rows']))
        last=self.directory.search('بورسلان','Riyadh',limit=30,offset=first['total']-1)
        self.assertEqual(len(last['rows']),1);self.assertFalse(last['has_more']);self.assertIsNone(last['next_offset'])
    def test_filter_and_name_priority_apply_before_page(self):
        result=self.directory.search('بورسلان','Riyadh',limit=200,filters={'sort':'name_first'})
        matches=[r['keyword_name_match'] for r in result['rows']]
        self.assertEqual(matches,sorted(matches,reverse=True))
        only=self.directory.search('بورسلان','Riyadh',limit=200,filters={'name_only':True})
        self.assertTrue(all(r['keyword_name_match'] for r in only['rows']))
        category=result['rows'][0]['category_main']
        filtered=self.directory.search('بورسلان','Riyadh',filters={'category':category})
        self.assertTrue(all(r['category_main']==category for r in filtered['_map_rows']))
        self.assertTrue(all(0<=r['match_confidence']['score']<=100 for r in result['rows']))
    def test_vector_tiles_include_entire_cohort_and_reuse_context(self):
        result=self.directory.search('بورسلان','Riyadh',limit=1)
        cohort=result['_map_rows'];key=self.tiles.register(rows=cohort)
        self.assertEqual(key,self.tiles.register(rows=list(cohort)))
        decoded=mapbox_vector_tile.decode(self.tiles.tile(key,0,0,0))['businesses']['features']
        expected=sum(r.get('location_precision','point')=='point' and r.get('latitude') is not None and r.get('longitude') is not None and -85.05112878<=r['latitude']<=85.05112878 and -180<=r['longitude']<180 for r in cohort)
        self.assertEqual(sum(f['properties']['count'] for f in decoded),expected)
        self.assertGreater(expected,len(result['rows']))
        self.assertIsNone(self.tiles.profile(key,'not-in-this-query'))
    def test_catalog_tiles_cover_every_located_filtered_row(self):
        filters={'category':'Shopping','entity_type':'company'}
        result=self.tiles.browse('Riyadh',filters,1)
        decoded=mapbox_vector_tile.decode(self.tiles.tile(result['map_query'],0,0,0))['businesses']['features']
        self.assertEqual(sum(f['properties']['count'] for f in decoded),result['located_total'])
        self.assertTrue(all('location_precision' in row for row in result['rows']))
        if result['rows']:
            row=self.tiles.profile(result['map_query'],result['rows'][0]['poi_key'])
            self.assertEqual(row['category_main'],'Shopping');self.assertEqual(row['entity_type'],'company')
    def test_approximate_locations_stay_list_only(self):
        result=self.tiles.browse('Riyadh',{},200)
        filters=valid_filters({});base,params=self.tiles.sql('Riyadh',filters)
        expected=self.tiles.db.execute("select count(*) filter(where coalesce(location_precision,'point')='point' and longitude between -180 and 180 and latitude between -85.05112878 and 85.05112878) "+base,params).fetchone()[0]
        self.assertEqual(result['located_total'],expected)
        self.assertTrue(all('location_precision' in row for row in result['rows']))
        decoded=mapbox_vector_tile.decode(self.tiles.tile(result['map_query'],0,0,0))['businesses']['features']
        self.assertEqual(sum(f['properties']['count'] for f in decoded),expected)
    def test_tile_boundaries_conserve_counts_and_invalid_requests_fail(self):
        result=self.tiles.browse('Riyadh',{'category':'Shopping'},1);key=result['map_query']
        count=0
        for x in range(2):
            for y in range(2):
                features=mapbox_vector_tile.decode(self.tiles.tile(key,1,x,y))['businesses']['features']
                count+=sum(f['properties']['count'] for f in features)
        self.assertEqual(count,result['located_total'])
        with self.assertRaises(ValueError): self.tiles.tile(key,21,0,0)
        with self.assertRaises(KeyError): self.tiles.tile('unknown',0,0,0)
        with self.assertRaises(ValueError): valid_filters({'bounds':[math.nan,1,2,3]})
        self.assertFalse(self.tiles.facets('Riyadh')['size_available'])
if __name__=='__main__':unittest.main()
