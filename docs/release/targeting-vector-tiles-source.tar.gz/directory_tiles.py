"""Authenticated, bounded vector tiles over the existing read-only POI directory."""
import collections
import json
import hashlib
import math
import re
import secrets
import threading
import time
import duckdb
import mapbox_vector_tile
from trial_search import norm, contains

LABELS={'Corporate':'شركات وأعمال','Shopping':'تسوق وتجارة','Restaurants':'مطاعم','Hotels and Accommodations':'فنادق وإقامة','Home Goods':'تجهيزات المنزل','Grocery':'مواد غذائية','Education':'تعليم','Beauty and Spa':'تجميل وعناية','Automotive Services':'خدمات السيارات','Transportation':'نقل','Health':'صحة','Medical':'طب','Mosques':'مساجد','decor_carpentry_furniture':'أثاث ونجارة','غير مصنف':'غير مصنف'}
def main_category(value): return (value or '').split('|')[0].strip() or 'غير مصنف'
def subcategories(*values):
    terms=[]
    for value in values:
        if not value: continue
        for term in re.split(r'[|,]',str(value)):
            term=term.strip(' {}[]\"\'')
            if 2<=len(term)<=100 and term not in terms: terms.append(term)
    return terms[:12]
def entity_kind(legal,name):
    text=norm(legal or name)
    if re.search(r'\b(شركه|شركات|company|corporation|llc)\b',text): return 'company'
    if re.search(r'\b(مؤسسه|establishment|est)\b',text): return 'establishment'
    return 'unknown'
def valid_filters(value):
    if value is None: return {}
    if not isinstance(value,dict): raise ValueError('invalid filters')
    out={}
    for key in ('category','subcategory','entity_type','contact','sort','keyword'):
        val=value.get(key,'')
        if not isinstance(val,str) or len(val)>100: raise ValueError('invalid filters')
        out[key]=val
    if out['entity_type'] not in ('','company','establishment','unknown'): raise ValueError('invalid entity type')
    if out['contact'] not in ('','all','whatsapp','email'): raise ValueError('invalid contact')
    if out['sort'] not in ('','confidence','name_first'): raise ValueError('invalid sort')
    out['branches_only']=value.get('branches_only') is True
    out['name_only']=value.get('name_only') is True
    bounds=value.get('bounds')
    if bounds is not None:
        if not isinstance(bounds,list) or len(bounds)!=4 or not all(type(x) in (float,int) and math.isfinite(x) for x in bounds) or not (-180<=bounds[0]<=bounds[2]<=180 and -85.1<=bounds[1]<=bounds[3]<=85.1): raise ValueError('invalid bounds')
        out['bounds']=bounds
    return out
def filter_rows(rows,filters):
    f=valid_filters(filters)
    out=[]
    for row in rows:
        if f.get('category') and row.get('category_main')!=f['category']: continue
        if f.get('subcategory') and f['subcategory'] not in row.get('subcategories',[]): continue
        if f.get('entity_type') and row.get('entity_type')!=f['entity_type']: continue
        if f.get('branches_only') and row.get('registered_location_count',0)<2: continue
        if f.get('name_only') and not row.get('keyword_name_match'): continue
        if f.get('contact')=='whatsapp' and not row.get('has_whatsapp'): continue
        if f.get('contact')=='email' and not row.get('email'): continue
        if f.get('bounds'):
            w,s,e,n=f['bounds'];lon,lat=row.get('longitude'),row.get('latitude')
            if lon is None or lat is None or not w<=lon<=e or not s<=lat<=n: continue
        out.append(row)
    out.sort(key=lambda row: (-(bool(row.get('keyword_name_match')) if f.get('sort')=='name_first' else 0),-row.get('match_confidence',{}).get('score',0)))
    return out

class DirectoryTiles:
    def __init__(self,path):
        self.path=path;self.lock=threading.RLock();self.contexts=collections.OrderedDict();self.tiles=collections.OrderedDict();self.facets_cache={};self.fingerprints={}
        self.db=duckdb.connect();self.db.execute("SET threads=2; SET memory_limit='512MB'")
        self.db.execute("""create table branches as select lower(trim(brand_name)) brand,
            count(distinct concat(city_en,':',round(latitude,4),':',round(longitude,4))) n
            from read_parquet(?) where length(trim(brand_name))>2 and latitude is not null and longitude is not null
            group by 1""",[path])
        self.branch_counts=dict(self.db.execute('select * from branches').fetchall())
    def facets(self,city):
        with self.lock:
            if city in self.facets_cache: return self.facets_cache[city]
            where='where city_en=?' if city and city!='*' else ''
            values=self.db.execute('select category,secondary_category,category_l3,count(*) from read_parquet(?) '+where+' group by 1,2,3',[self.path]+([city] if where else [])).fetchall()
            groups={}
            for main,sub,l3,count in values:
                main=main_category(main);g=groups.setdefault(main,{'value':main,'label':LABELS.get(main,main),'count':0,'subcategories':{}});g['count']+=count
                for term in subcategories(sub,l3): g['subcategories'][term]=g['subcategories'].get(term,0)+count
            result={'categories':[dict(g,subcategories=[{'value':k,'label':k,'count':n} for k,n in sorted(g['subcategories'].items(),key=lambda pair:-pair[1])]) for g in sorted(groups.values(),key=lambda g:-g['count'])],'size_available':False,'entity_type_source':'name_inference','branches_source':'distinct_registered_brand_locations'}
            self.facets_cache[city]=result;return result
    def register(self,rows=None,city=None,filters=None):
        f=valid_filters(filters)
        with self.lock:
            fingerprint=hashlib.sha256(json.dumps([city,f,[r['poi_key'] for r in rows] if rows is not None else None],sort_keys=True).encode()).hexdigest()
            old=self.fingerprints.get(fingerprint)
            if old in self.contexts and self.contexts[old][0]>time.monotonic():self.contexts.move_to_end(old);return old
            key=secrets.token_hex(16);self.contexts[key]=(time.monotonic()+1800,rows,city,f);self.fingerprints[fingerprint]=key
            if len(self.fingerprints)>64:self.fingerprints={k:v for k,v in self.fingerprints.items() if v in self.contexts}
            while len(self.contexts)>32:self.contexts.popitem(last=False)
        return key
    def context(self,key):
        item=self.contexts.get(key)
        if not item or item[0]<time.monotonic(): raise KeyError('MAP_QUERY_EXPIRED')
        return item
    def sql(self,city,f,bounds=None):
        clauses=["coalesce(lifecycle_state,'') not in ('closed','permanently_closed')","coalesce(company_status,'') not in ('cancelled','inactive','ملغي','ملغى')","coalesce(nullif(name_ar,''),name_en) is not null"]
        params=[self.path]
        if city and city!='*':clauses.append('city_en=?');params.append(city)
        if f.get('category'):clauses.append("coalesce(nullif(trim(split_part(coalesce(category,''),'|',1)),''),'غير مصنف')=?");params.append(f['category'])
        if f.get('subcategory'):clauses.append("(regexp_matches(coalesce(secondary_category,''),?) or regexp_matches(coalesce(category_l3,''),?))");params.extend([r'''(^|[|,\[{])\s*["']?'''+re.escape(f['subcategory'])+r'''["']?\s*($|[|,\]}])''']*2)
        identity="translate(lower(coalesce(nullif(legal_name,''),name_ar,name_en,'')),'أإآةىؤئ','اااهيوي')"
        company="regexp_matches("+identity+",'(^|[^[:alnum:]؀-ۿ])(شركه|شركات|company|corporation|llc)($|[^[:alnum:]؀-ۿ])')"
        institution="regexp_matches("+identity+",'(^|[^[:alnum:]؀-ۿ])(مؤسسه|establishment|est)($|[^[:alnum:]؀-ۿ])')"
        if f.get('entity_type')=='company':clauses.append(company)
        elif f.get('entity_type')=='establishment':clauses.extend(['not '+company,institution])
        elif f.get('entity_type')=='unknown':clauses.extend(['not '+company,'not '+institution])
        if f.get('name_only'):
            keyword=norm(f.get('keyword',''))
            if not keyword:raise ValueError('name filter needs keyword')
            clauses.append("contains(regexp_replace(translate(lower(concat_ws(' ',name_ar,name_en)),'أإآةىؤئ','اااهيوي'),'[ً-ْـ]','','g'),?)");params.append(keyword)
        if f.get('branches_only'):clauses.append('coalesce(b.n,0)>=2')
        if f.get('contact')=='whatsapp':clauses.append('has_whatsapp=true')
        if f.get('contact')=='email':clauses.append("length(trim(coalesce(email,'')))>0")
        for bound in [f.get('bounds'),bounds]:
            if bound:
                clauses.append('longitude>=? and latitude>=? and longitude<? and latitude<?');params.extend(bound)
        base="from read_parquet(?) p left join branches b on lower(trim(p.brand_name))=b.brand where "+' and '.join(clauses)
        return base,params
    def browse(self,city,filters,limit=30,offset=0):
        if type(limit) is not int or not 1<=limit<=200 or type(offset) is not int or offset<0:raise ValueError('invalid pagination')
        f=valid_filters(filters);base,params=self.sql(city,f)
        with self.lock:
            total,located=self.db.execute('select count(*),count(*) filter(where longitude between -180 and 180 and latitude between -85.05112878 and 85.05112878) '+base,params).fetchone()
            cursor=self.db.execute("select poi_key,name_ar,name_en,category,category_ar,secondary_category,category_l3,city_en,region_en,region_ar,district_ar,district_en,latitude,longitude,phone_norm as phone,phone_kind,has_whatsapp,email,sources,source_count,legal_name,coalesce(b.n,0) registered_location_count "+base+' order by completeness_pct desc,poi_key limit ? offset ?',params+[limit,offset])
            names=[d[0] for d in cursor.description];rows=[dict(zip(names,row)) for row in cursor.fetchall()]
        for row in rows:
            row.update(category_main=main_category(row['category']),subcategories=subcategories(row['secondary_category'],row['category_l3']),entity_type=entity_kind(row.get('legal_name'),row.get('name_ar') or row.get('name_en')),reason='نتيجة من التصنيف المسجل؛ ليست توصية شراء أو طلبًا مؤكدًا')
        return {'rows':rows,'total':total,'located_total':located,'offset':offset,'has_more':offset+len(rows)<total,'next_offset':offset+len(rows) if offset+len(rows)<total else None,'map_query':self.register(city=city,filters=f),'parsed':{'city':city},'with_whatsapp':sum(bool(r.get('has_whatsapp')) for r in rows),'with_email':sum(bool(r.get('email')) for r in rows),'by_region':[]}
    def profile(self,key,poi_key):
        with self.lock:
            _,rows,city,f=self.context(key)
            if rows is not None:
                return next((r for r in rows if r['poi_key']==poi_key),None)
            base,params=self.sql(city,f)
            cursor=self.db.execute('select p.* '+base+' and poi_key=? limit 1',params+[poi_key]);names=[d[0] for d in cursor.description];values=cursor.fetchone()
            if not values:return None
            row=dict(zip(names,values));row['phone']=row.pop('phone_norm',None);row['registered_location_count']=self.branch_counts.get((row.get('brand_name') or '').strip().lower(),0)
            row.update(category_main=main_category(row['category']),subcategories=subcategories(row['secondary_category'],row['category_l3']),entity_type=entity_kind(row.get('legal_name'),row.get('name_ar') or row.get('name_en')))
            return row
    def tile(self,key,z,x,y):
        if not 0<=z<=20 or not 0<=x<2**z or not 0<=y<2**z:raise ValueError('invalid tile')
        cache_key=(key,z,x,y)
        with self.lock:
            _,rows,city,f=self.context(key)
            if cache_key in self.tiles:self.tiles.move_to_end(cache_key);return self.tiles[cache_key]
            size=2**z;west=x/size*360-180;east=(x+1)/size*360-180
            north=math.degrees(math.atan(math.sinh(math.pi*(1-2*y/size))));south=math.degrees(math.atan(math.sinh(math.pi*(1-2*(y+1)/size))))
            if rows is not None:
                points=[(r['poi_key'],r.get('name_ar') or r.get('name_en') or '',r['longitude'],r['latitude']) for r in rows if r.get('longitude') is not None and r.get('latitude') is not None and west<=r['longitude']<east and south<=r['latitude']<north]
            else:
                base,params=self.sql(city,f,[west,south,east,north])
                grid=1024 if z<12 else 512 if z<16 else 1
                px=f'((longitude+180)/360*{size}-{x})*4096'
                py=f'((1-asinh(tan(radians(latitude)))/pi())/2*{size}-{y})*4096'
                grouped=self.db.execute(f"select floor(({px})/{grid}),floor(({py})/{grid}),avg({px}),avg({py}),count(*),first(poi_key),first(coalesce(name_ar,name_en)) "+base+" and latitude between -85.05112878 and 85.05112878 group by 1,2",params).fetchall()
                points=[]
            cells={};grid=1024 if z<12 else 512 if z<16 else 1
            for poi,name,lon,lat in points:
                if not -85.05112878<=lat<=85.05112878:continue
                px=((lon+180)/360*size-x)*4096;py=((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*size-y)*4096
                cell=(int(px//grid),int(py//grid));entry=cells.setdefault(cell,{'px':0,'py':0,'count':0,'key':poi,'name':name});entry['px']+=px;entry['py']+=py;entry['count']+=1
            if rows is None:
                cells={(cx,cy):{'px':px*n,'py':py*n,'count':n,'key':poi,'name':name} for cx,cy,px,py,n,poi,name in grouped}
            features=[{'geometry':{'type':'Point','coordinates':[r['px']/r['count'],r['py']/r['count']]},'properties':{'key':r['key'] if r['count']==1 else '', 'name':r['name'] if r['count']==1 else str(r['count'])+' مواقع','count':r['count']}} for r in cells.values()]
            data=mapbox_vector_tile.encode({'name':'businesses','features':features},default_options={'y_coord_down':True,'extents':4096})
            self.tiles[cache_key]=data
            while len(self.tiles)>128 or sum(len(v) for v in self.tiles.values())>32*1024*1024:self.tiles.popitem(last=False)
            return data
